# FIFA-WORLD-CUP-ANALYSIS

### Note - All the pictorial representation of data might not be present in Jupyter notebook due to some error while uploading so you can refer to the pdf version of Jupyter notebook for complete analysis. If the pdf version shows error while opening, download the pdf using download button present over there. This download would be successful and you can have a complete preview of analysis project.

Problem Statement:

With FIFA being in the blood as many people of the world. You are tasked to tell the story of unsung analysts who put great efforts to provide accurate data to answer every question of fans.

The FIFA World Cup is a global football competition contested by the various football- playing nations of the world. It is contested every four years and is the most prestigious and important trophy in the sport of football.

The World Cups dataset show all information about all the World Cups in the history, hile the World Cup Matches dataset shows all the results from the matches contested
as part of the cups. 

AIM - Find key metrics and factors that influence the World Cup win.

Dataset:
This data is courtesy of the FIFA World Cup Archive website.
https://drive.google.com/drive/folders/12oHYj0qH2uZD8I13cVDiymTNDYldeJRa?usp=sharing


 Insights,

 Insight 1 : Brazil has won the tournament most number of times

 Insight 2 : A complete depection of number of world cups won, first runner-up, and second runner-up positions by various participating teams

 Insight 3 : Brazil scored the most number of goals thrughout the history of worldcup followed by Argentina and Germany.

 Insight 4 : Brazil has again scored a majority of total goals playing as home team whereas spain scored more goals playing as away country rather than home country

 Insight 5 : 73.6 % of the matches were won by home team while 26.4 % were won by away team. 

 Insight 6 : Brazil has played the most bnumber of players followed by Italy and Argentina

 Insight 7 : Most of the teams have played between 0  and 500 players only in the complete competition, and handful of countries have played more than 1500 players in the history of competition.
